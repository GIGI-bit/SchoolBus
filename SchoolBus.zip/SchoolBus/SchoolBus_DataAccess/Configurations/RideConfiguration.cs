﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using SchoolBus_Models.Entities.Concretes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolBus_DataAccess.Constraits
{
    internal class RideConfiguration : IEntityTypeConfiguration<Ride>
    {
        public void Configure(EntityTypeBuilder<Ride> builder)
        {
            builder.Ignore(x => x.Name);
            builder.Property(x=>x.SeatCount).HasDefaultValue(6);
            builder.Property(x=>x.S_Count).HasDefaultValue(0);
            builder.HasOne(r => r.Car)
                .WithOne(r => r.Ride)
                .HasForeignKey<Ride>(r => r.CarId)
                .OnDelete(DeleteBehavior.Cascade);
            builder.HasOne(r => r.Driver)
            .WithOne(r => r.Ride)
            .HasForeignKey<Ride>(r => r.DriverId)
            .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
