﻿using SchoolBus_Models.Entities.Abstracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolBus_DataAccess.Repositories.Abstracts
{
    public interface IBaseRepository<T> where T:BaseEntity,new()
    {
        ICollection<T>? GetAll();
        T? GetById(int id);
        void Add(T entity);
        void Update(T entity);
        void Remove(int id);
        void Remove(T entiity);
        void SaveChanges();
    }
}
