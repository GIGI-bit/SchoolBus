﻿using SchoolBus_DataAccess.DataBase;
using SchoolBus_DataAccess.Repositories.Abstracts;
using SchoolBus_Models.Entities.Abstracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolBus_DataAccess.Repositories.Concretes
{
    public class BaseRepository<T> : IBaseRepository<T> where T: BaseEntity,new()
    {
        internal readonly SchoolBus_DB _context;

        public BaseRepository()
        {
            _context=new SchoolBus_DB();
        }
        public void Add(T entity)
        {
            if (entity == null) throw new ArgumentNullException("Entity You've sent is null!");
            _context.Set<T>().Add(entity);
        }

        public ICollection<T>? GetAll()
        {
            return _context?.Set<T>().ToList();
        }

        public T? GetById(int id)
        {
            if(id < 0)throw new ArgumentOutOfRangeException("Id is invalid!");
            var aut = _context.Set<T>().FirstOrDefault(x => x.Id == id);
            if (aut == null) throw new Exception("This Entity does NOT exist!");
            return aut;
        }

        public void Remove(int id)
        {
            if (id < 0) throw new ArgumentOutOfRangeException("Id is invalid!");
            var aut = _context.Set<T>().FirstOrDefault(x => x.Id == id);
            if (aut == null) throw new Exception("This Entity does NOT exist!");
            _context.Set<T>().Remove(aut);
        }

        public void Remove(T entiity)
        {
            if (entiity == null) throw new Exception("This Entity does NOT exist!");
            _context.Set<T>().Remove(entiity);
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }

        public void Update(T entity)
        {
            if (entity == null) throw new Exception("This Entity does NOT exist!");
            _context.Set<T>().Update(entity);
        }
    }
}
