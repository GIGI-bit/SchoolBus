﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp1;

namespace SchoolBus_DesktopAPP.ViewModels.Windows
{
    internal class EntranceViewModel
    {
        public EntranceViewModel()
        {
            var view=App._container.GetInstance<MainWindow>();
        }
    }
}
