﻿using FluentAPI.MyCommands;
using SchoolBus_DesktopAPP.ViewModels.Windows;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1;

namespace SchoolBus_DesktopAPP.Views.Windows
{
    /// <summary>
    /// Interaction logic for EntranceWindow.xaml
    /// </summary>
    public partial class EntranceWindow : NavigationWindow
    {
        public MyRelayCommand BTN {  get; set; }
        public EntranceWindow()
        {
            InitializeComponent();
            //DataContext = App._container.GetInstance<EntranceViewModel>();


            BTN = new MyRelayCommand(exec);

        }

        private void exec(object? obj)
        {
            frame.Navigate(new Window1());
        }
    }
}
