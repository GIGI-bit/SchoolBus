﻿
using SchoolBus_DesktopAPP.ViewModels.Windows;
using SchoolBus_DesktopAPP.Views.Windows;
using SimpleInjector;
using System.Configuration;
using System.Data;
using System.Windows;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static Container? _container;
        private void MainStart(object sender, StartupEventArgs e)
        {
            register();
            var view = _container.GetInstance<EntranceWindow>();
            view.ShowDialog();
        }
        private void register()
        {
            _container=new Container();
            _container.RegisterSingleton<MainWindow>();
            _container.RegisterSingleton<EntranceWindow>();
            _container.RegisterSingleton<EntranceViewModel>();
            _container.Verify();
        }
    }

}
