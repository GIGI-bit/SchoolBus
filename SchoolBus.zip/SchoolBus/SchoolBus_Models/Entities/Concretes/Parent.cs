﻿using SchoolBus_Models.Entities.Abstracts;

namespace SchoolBus_Models.Entities.Concretes
{
    public class Parent:BaseEntity
    {
        public string LastName { get; set; }
        public string Phone {  get; set; }
        public string Username { get; set; }
        public string Password {  get; set; }
        public int StudentId { get; set; }
        //Nav
        public virtual Student Student { get; set; }
        public Parent() { }
    }
}