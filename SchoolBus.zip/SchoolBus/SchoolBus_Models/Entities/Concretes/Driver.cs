﻿using SchoolBus_Models.Entities.Abstracts;

namespace SchoolBus_Models.Entities.Concretes
{
    public class Driver:BaseEntity
    {
        public string LastName { get; set; }
        public string Phone {  get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string HouseAddress { get; set; }
        public string Licence { get; set; }
        public int RideId { get; set; }
        //Nav
        public virtual Ride Ride { get; set; }
        public Driver() { }
    }
}