﻿using SchoolBus_Models.Entities.Abstracts;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SchoolBus_Models.Entities.Concretes
{
    public class Ride:BaseEntity
    {
        public int DriverId { get; set; }

        public int CarId { get; set; }
        public string From {  get; set; }
        public string To { get; set; }
        public int S_Count { get; set; }
        public int SeatCount { get; set; }
        //Nav 
        public virtual ICollection<Student> Student { get; set; }
        public virtual Car Car{ get; set; }
        public virtual Driver Driver { get; set; }
        public Ride()
        {
            
        }

    }
}