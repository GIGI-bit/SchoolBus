﻿using SchoolBus_Models.Entities.Abstracts;
using System.Buffers.Text;

namespace SchoolBus_Models.Entities.Concretes
{
    public class Car:BaseEntity
    {
        public int SeatCount { get; set; }
        public string Type { get; set; }
        public int RideId { get; set; }
        public virtual Ride Ride { get; set; }
        public Car()
        {
            
        }
    }
}