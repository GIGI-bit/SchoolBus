﻿using SchoolBus_Models.Entities.Abstracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolBus_Models.Entities.Concretes
{
    public class Class:BaseEntity
    {
        public int S_Count { get; set; }
        //Nav
        public virtual ICollection<Student> Student {  get; set; }
        public Class()
        {
            
        }
    }
}
