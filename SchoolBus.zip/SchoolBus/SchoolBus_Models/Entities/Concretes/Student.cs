﻿using SchoolBus_Models.Entities.Abstracts;
using System.Globalization;

namespace SchoolBus_Models.Entities.Concretes
{
    public class Student:BaseEntity
    {
        public string LastName { get; set; }
        public string HomeAddress { get; set; }
        public string SchoolAddress { get; set; }
        public int? RideId { get; set; }
        public int ParentId { get; set; }
        public int ClassId { get; set; }
        //Nav
        public virtual Class Class { get; set; }
        public virtual Ride Ride { get; set; }
        public virtual ICollection<Parent> Parent {  get; set; }

        public Student() { } 

    }
}