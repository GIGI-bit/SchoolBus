﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading.Tasks;
using System.Media;
using System.Numerics;

namespace SchoolBus_DesktopApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //MediaPlayer player;
        public MainWindow()
        {
            InitializeComponent();
            //player = new MediaPlayer();
            //player.Open(new Uri("C:\\Users\\Sevgi\\source\\repos\\SchoolBus\\SchoolBus_DesktopApp\\Medias\\honk.mp3"));
            //player.Play();
            //Loaded += StartLoading;

        }
        //private async void StartLoading(object sender, RoutedEventArgs e)
        //{

        //    await Task.Delay(7000);
        //    player.Stop();
        //    this.Close();
        //}
    }
}