﻿using FluentAPI.MyCommands;
using SchoolBus_WPFApp.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace SchoolBus_WPFApp.ViewModel
{
    internal class SignUpViewModel:INotifyPropertyChanged
    {
        private string _name;
        private string _surname;
        private string _username;
        private string _password;
        public string Name { get => _name; set { _name = value; OnPropertyChanged(); } }
        public string Surname { get => _surname; set { _surname = value; OnPropertyChanged(); } }
        public string Username { get => _username; set { _username = value; OnPropertyChanged(); } }
        public string Password { get => _password; set { _password = value; OnPropertyChanged(); } }

        public MyRelayCommand SignUp {  get; set; }
        public MyRelayCommand Back {  get; set; }
        public SignUpViewModel()
        {
            SignUp = new MyRelayCommand(SignExec);
            Back = new MyRelayCommand(BackExec);
        }

        private void BackExec(object? obj)
        {
            if(obj is Page page)
            {
                page.NavigationService.GoBack();
            }
        }

        private void SignExec(object? obj)
        {
            if(obj is Page page)
            {
                page.NavigationService.Navigate(App._container.GetInstance<MainPageView>());
            }
        }
        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
