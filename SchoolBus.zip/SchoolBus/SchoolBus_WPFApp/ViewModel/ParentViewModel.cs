﻿using FluentAPI.MyCommands;
using SchoolBus_WPFApp.Views.CreatePages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolBus_WPFApp.ViewModel
{
    internal class ParentViewModel
    {
        public MyRelayCommand CreateParent {  get; set; }
        public ParentViewModel()
        {
            CreateParent = new MyRelayCommand(createExec);
        }

        private void createExec(object? obj)
        {
            var window=new CreatePopUp(App._container.GetInstance<CreateParentView>());
            window.ShowDialog();
        }
    }
}
