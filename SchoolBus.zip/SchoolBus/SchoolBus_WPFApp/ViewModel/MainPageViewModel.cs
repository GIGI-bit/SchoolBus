﻿using FluentAPI.MyCommands;
using SchoolBus_WPFApp.Views;
using SchoolBus_WPFApp.Views.CreatePages;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;

namespace SchoolBus_WPFApp.ViewModel
{
    internal class MainPageViewModel:INotifyPropertyChanged
    {
        
        public MyRelayCommand CreateRide {  get; set; }
        public MyRelayCommand Ride { get; set; }
        public MyRelayCommand Class{ get; set; }
        public MyRelayCommand Student{ get; set; }
        public MyRelayCommand Parent{ get; set; }
        public MyRelayCommand Driver{ get; set; }
        public MyRelayCommand Car{ get; set; }
        public MainPageViewModel()
        {
            CreateRide = new MyRelayCommand(rideExec);
            Ride = new MyRelayCommand(Rexec);
            Class = new MyRelayCommand(classExec);
            Student = new MyRelayCommand(studExec);
            Parent = new MyRelayCommand(parExec);
            Driver = new MyRelayCommand(DrivExec);
            Car = new MyRelayCommand(carexec);
        }

        private void carexec(object? obj)
        {
            if (obj is Frame frame) frame.Navigate(App._container.GetInstance<CarView>());
        }

        private void DrivExec(object? obj)
        {
            if (obj is Frame frame) frame.Navigate(App._container.GetInstance<DriverView>());
        }

        private void parExec(object? obj)
        {
            if (obj is Frame frame) frame.Navigate(App._container.GetInstance<ParentView>());
        }

        private void studExec(object? obj)
        {
            if (obj is Frame frame) frame.Navigate(App._container.GetInstance<StudentView>());
        }

        private void classExec(object? obj)
        {
            if (obj is Frame frame) frame.Navigate(App._container.GetInstance<ClassView>());
        }

        private void Rexec(object? obj)
        {
            if (obj is Frame frame)
            {
                frame.Navigate(App._container.GetInstance<RideView>());
            }
        }

        private void rideExec(object? obj)
        {
            if (obj is Frame frame) frame.Navigate(App._container.GetInstance<CreateRideView>());
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
