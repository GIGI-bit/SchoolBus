﻿using SchoolBus_Models.Entities.Concretes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace SchoolBus_WPFApp.ViewModel.CreateViewModel
{
    internal class CreateRideViewModel : INotifyPropertyChanged
    {
        private List<Student> first_items;
        private List<Student> second_items;
        public List<Student> FirstItems { get => first_items; set { first_items = value; OnPropertyChanged(); } }
        public List<Student> SecondItems { get => second_items; set { second_items = value; OnPropertyChanged(); } }
        public CreateRideViewModel()
        {
            FirstItems = new List<Student>() { new Student() { Name = "Sevgi", LastName = "sssssa", ParentId = 6, ClassId = 2 } };
        }
        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
