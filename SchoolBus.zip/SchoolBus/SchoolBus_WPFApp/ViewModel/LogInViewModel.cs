﻿using FluentAPI.MyCommands;
using SchoolBus_WPFApp.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace SchoolBus_WPFApp.ViewModel
{
    internal class LogInViewModel:INotifyPropertyChanged
    {
        private string _username;
        private string _password;
        public string Username { get => _username; set { _username = value;OnPropertyChanged(); } }
        public string Password { get => _password; set { _password = value;OnPropertyChanged(); } }
        public MyRelayCommand LogIn {  get; set; }
        public MyRelayCommand SignUp {  get; set; }
        public LogInViewModel()
        {
            LogIn = new MyRelayCommand(Exec);
            SignUp = new MyRelayCommand(SignExec);
        }

        private void SignExec(object? obj)
        {
            if (obj is Page page)
            {
                page.NavigationService.Navigate(App._container.GetInstance<SignUpView>());
            }
        }

        private void Exec(object? obj)
        {
            if(obj is Page page)
            {
                page.NavigationService.Navigate(App._container.GetInstance<MainPageView>());
            }
        }
        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
