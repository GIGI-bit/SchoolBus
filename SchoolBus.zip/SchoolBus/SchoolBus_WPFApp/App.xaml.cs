﻿using SchoolBus_WPFApp.ViewModel;
using SchoolBus_WPFApp.ViewModel.CreateViewModel;
using SchoolBus_WPFApp.Views;
using SchoolBus_WPFApp.Views.CreatePages;
using SimpleInjector;
using System.Configuration;
using System.Data;
using System.Windows;

namespace SchoolBus_WPFApp
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static Container _container;
        private void MainStart(object sender, StartupEventArgs e)
        {
            register();
            var view = _container.GetInstance<MainWindow>();
            view.ShowDialog();

        }
        public void register()
        {
            _container=new Container();
            _container.RegisterSingleton<MainWindow>();
            _container.RegisterSingleton<MainViewModel>();
            _container.RegisterSingleton<MainPageViewModel>();
            _container.RegisterSingleton<MainPageView>();
            _container.RegisterSingleton<LogInView>();
            _container.RegisterSingleton<LogInViewModel>();
            _container.RegisterSingleton<SignUpView>();
            _container.RegisterSingleton<SignUpViewModel>();
            _container.RegisterSingleton<CreateRideView>();
            _container.RegisterSingleton<CreateRideViewModel>();
            _container.RegisterSingleton<RideView>();
            _container.RegisterSingleton<RideViewModel>();
            _container.RegisterSingleton<ClassView>();
            _container.RegisterSingleton<ClassViewModel>();
            _container.RegisterSingleton<StudentView>();
            _container.RegisterSingleton<StudentViewModel>();
            _container.RegisterSingleton<ParentView>();
            _container.RegisterSingleton<ParentViewModel>();
            _container.RegisterSingleton<DriverView>();
            _container.RegisterSingleton<DriverViewModel>();
            _container.RegisterSingleton<CarView>();
            _container.RegisterSingleton<CarViewModel>();
            _container.RegisterSingleton<CreateStudentView>();
            _container.RegisterSingleton<CreateStudentViewModel>();
            _container.RegisterSingleton<CreateParentView>();
            _container.RegisterSingleton<CreateParentViewModel>();
            _container.Verify();
        }
    }

}
